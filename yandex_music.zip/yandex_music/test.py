import requests

with open('./random-mp3.mp3', 'rb') as file:
    filedata = file.read()

# тест пустого запроса
resp = requests.post('http://127.0.0.1:8000/api/v1/audios/add',
                     files={'audiofile': filedata})

print(resp, resp.json())

# resp = requests.get('http://127.0.0.1:8000/api/v1/audios/list')

# print(resp, resp.json())



