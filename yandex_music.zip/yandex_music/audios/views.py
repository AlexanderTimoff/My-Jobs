from rest_framework import generics
from django.http import JsonResponse, FileResponse
from django.shortcuts import render
from .models import AudioFile, uuid4
from yandex_music.settings import MEDIA_URL, os


class AddAudioFileApi(generics.CreateAPIView):
    """Добавление нового аудиофайла в базу"""
    queryset = AudioFile

    def create(self, request, *args, **kwargs):
        file = request.FILES.get('audiofile')
        if not file:
            return JsonResponse({'error': 'audiofile not defined'})
        
        buff = file.read()
        filename = str(uuid4())
        filepath = MEDIA_URL + filename +'.mp3'

        try:
            with open(filepath, 'wb') as file:
                file.write(buff)

            AudioFile.objects.create(name=filename, link=filepath)
            return JsonResponse({'result': 'saved success'})
        except Exception as e:
            return JsonResponse({'error': str(e)})


class ListAudioFileApi(generics.ListAPIView):
    queryset = AudioFile
    def get(self, request, *args, **kwargs):
        audiofiles = list(AudioFile.objects.all())
        serialized = []
        for file in audiofiles:
            link = f'http://127.0.0.1:8000/audio?id={file.id}'
            serialized.append({
                'id': str(file.id),
                'name': file.name,
                'link': link,
            })
        return JsonResponse({'result': serialized})
    
def audio_player(request):
    audio_id = request.GET.get('id')
    try:
        audio_file = AudioFile.objects.get(id=audio_id)
        filepath = os.path.join(MEDIA_URL, audio_file.name + '.mp3')
        return FileResponse(open(filepath, 'rb'), content_type='audio/mpeg')
    except AudioFile.DoesNotExist:
        return JsonResponse({'error': 'File not found'}, status=404)
    
    
def audio_player_page(request):
    audio_id = request.GET.get('id')
    if not audio_id:
        return JsonResponse({'error': 'ID not find'}, status=400)

    return render(request, 'audio_player.html', {'audio_id': audio_id})