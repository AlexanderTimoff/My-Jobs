from flask import Flask, request, jsonify

app = Flask(__name__)

class XO:
    def __init__(self) -> None:
        self.map = [
            [0 for _ in range(3)]
            for _ in range(3)
        ]
        self.step = 1
        self.current_player = 0
        self.players = ["Player 1", "Player 2"]

    def make_move(self, x, y):
        if 0 <= x < 3 and 0 <= y < 3 and self.map[y][x] == 0:
            self.map[y][x] = 1 if self.current_player == 0 else 2
            self.step += 1
            self.current_player = (self.current_player + 1) % 2
            return True
        return False

    def check_winner(self):
        for row in self.map:
            if row[0] == row[1] == row[2] != 0:
                return True

        for col in range(3):
            if self.map[0][col] == self.map[1][col] == self.map[2][col] != 0:
                return True

        if self.map[0][0] == self.map[1][1] == self.map[2][2] != 0:
            return True

        if self.map[0][2] == self.map[1][1] == self.map[2][0] != 0:
            return True

        return False

    def get_board(self):
        return self.map

    def restart_game(self):
        self.map = [[0 for _ in range(3)] for _ in range(3)]
        self.step = 1
        self.current_player = 0

game = XO()

@app.route('/move', methods=['POST'])
def move():
    data = request.json
    x = data.get('x')
    y = data.get('y')

    if game.make_move(x, y):
        winner = game.check_winner()
        return jsonify({'board': game.get_board(), 'winner': winner, 'current_player': game.players[game.current_player]})
    else:
        return jsonify({'error': 'Invalid move!'}), 400

@app.route('/board', methods=['GET'])
def board():
    return jsonify({'board': game.get_board()})

@app.route('/restart', methods=['POST'])
def restart():
    game.restart_game()
    return jsonify({'message': 'Game restarted!', 'board': game.get_board()})

if __name__ == '__main__':
    app.run(debug=True)
