import requests

SERVER_URL = 'http://127.0.0.1:5000'

def draw_board(board):
    print("  1 2 3")
    for i, row in enumerate(board):
        print(f"{i + 1} {' '.join('X' if cell == 1 else 'O' if cell == 2 else '.' for cell in row)}")

def make_move():
    x = int(input('Введите x (1-3): ')) - 1
    y = int(input('Введите y (1-3): ')) - 1
    response = requests.post(f'{SERVER_URL}/move', json={'x': x, 'y': y})
    if response.status_code == 200:
        data = response.json()
        draw_board(data['board'])
        if data['winner']:
            print(f"Поздравляем, игра окончена! Выиграл:  {data['current_player']}")
            restart = input("Хотите начать заново? (y/n): ")
            if restart.lower() == 'y':
                requests.post(f'{SERVER_URL}/restart')
            if restart.lower() == 'n':
                print(f"Спасибо за игру!")
        else:
            print(f"Ход следующего игрока: {data['current_player']}")
    else:
        print(response.json()['error'])

def main():
    while True:
        draw_board(requests.get(f'{SERVER_URL}/board').json()['board'])
        make_move()

if __name__ == '__main__':
    main()
