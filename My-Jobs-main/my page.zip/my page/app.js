VANTA.WAVES({
    el: "#container",
    mouseControls: true,
    touchControls: true,
    gyroControls: false,
    minHeight: 200.00,
    minWidth: 200.00,
    scale: 1.00,
    scaleMobile: 1.00,
    color: 0xa1a59,
    shininess: 11.00,
    waveHeight: 10.50,
    waveSpeed: 1.05,
    zoom: 0.65
  })